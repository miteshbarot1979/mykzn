<?php 
echo "Start";
?>
<html>
	<head>
		<title>Welcome to PHP</title>
	</head>
	<body>
		<h1>Welcome to PHP</h1>
		<p><?php echo "Hello";?></p>
	</body>
</html>

<?php 
echo "END";
?>