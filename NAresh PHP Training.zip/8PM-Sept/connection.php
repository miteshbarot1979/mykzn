<?php 
	$con = mysqli_connect("localhost","root","","8pmoct") or die("sorry! Unable to connect to DB");
?>