<?php


$name = "Ram";
$price = 10.5;
$status = true;
$c = 10;
$c = "Welcome";

//echo $NaMe;


?>

