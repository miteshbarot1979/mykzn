<?php 
// display the event numbers 1 to 10 numbers
// display the prime nubers between 2 and 20

$i = 15;
do{
	echo $i."<br>";
	$i++;
}
while($i <= 10);





/*
$i = 15;
while($i<=10)
{
	echo $i."<br>";
	$i++;
}
*/





/*
$i = 1;
$table = 19;
while($i <= 10)
{
	echo $table."*".$i."=".$table*$i."<br>";
	$i++;
}
*/

/*
for($i = 1; $i <= 10; $i++)
{
	if($i % 2 == 1)
	{
		echo $i."<br>";
	}
}
*/

/*for($i = 10; $i >= 1; $i--)
{
	echo $i."<br>";
}*/





/*for($i = 1; $i <= 10; $i++)
{
	//echo $i;
	//echo "<br>";
	
	echo $i."<br>";
}
*/

?>