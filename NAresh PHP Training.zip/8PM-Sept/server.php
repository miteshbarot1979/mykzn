<?php
//echo "<pre>";
//echo $_SERVER['PHP_SELF'];
//echo $_SERVER['SCRIPT_FILENAME'];
//echo $_SERVER['DOCUMENT_ROOT'];
//echo $_SERVER['SERVER_NAME'];

//echo $_SERVER['HTTP_USER_AGENT'];

// IP address

//echo $_SERVER['REMOTE_ADDR'];

?>