<?php 
class Employee
{
	
}

?>