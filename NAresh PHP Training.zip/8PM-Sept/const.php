
<?php 

echo "hello";

//Magic constants

//echo "<img src=''/>";

define("CITY","Hyderabad");
define("STATE","TS");
echo CITY;
echo "<br>";
echo STATE;

/*
const CITY = "Hyderabad";
const STATE = "TS";

echo CITY;

echo STATE;

const CITY = "Mumbai";
*/

?>