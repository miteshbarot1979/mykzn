<html>
	<head>
		<title>Session and Cookie</title>
	</head>
	<body>
		<h1>Person1</h1>
		<form method="POST" action="p2.php">
			Number1:<input type="text" name="num1" />
			<input type="submit" value="Go">
		</form>
	</body>
</html>