<?php 
echo "<pre>";

$name = $_REQUEST['username'];
$mail = $_REQUEST['email'];
$pwd = $_REQUEST['pass'];
echo $name,$mail,$pwd;



//print_r($_POST);

/*$name = $_POST['username'];
$mail = $_POST['email'];
$pwd = $_POST['pass'];
echo $name,$mail,$pwd;
*/

//print_r($_GET);

/*$name = $_GET['username'];
$mail = $_GET['email'];
$pwd = $_GET['pass'];
echo $name,$mail,$pwd;
*/
//connect to database

// Insert the Data

// SUCCESS

?>


