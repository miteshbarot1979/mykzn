<ul class="mainmenu">
	<li><a href="home.php">Home</a></li>
	<li><a href="edit.php">Edit Profile</a></li>
	<li><a href="changepwd.php">Change Password</a></li>
	<li><a href="avatar.php">Upload Avatar</a></li>
	<li><a href="logout.php">Logout</a></li>
</ul>