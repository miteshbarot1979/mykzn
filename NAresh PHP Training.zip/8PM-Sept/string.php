<pre>
<?php 
//$str = "this is HTML class";

$pwd = "Ram@123";

//echo base64_encode($pwd);
//echo base64_decode("UmFtQDEyMw==");


//$pwd = "Ram@123";
//echo  password_hash($pwd,PASSWORD_DEFAULT);

/*$pwd = "Ram@1234";
$dbpwd ='$2y$10$Z1scTc5W0GaNVOJdUithtuHmsoT3tlIfAiWLrVPqXjLo9TB/U7.My';
echo password_verify($pwd,$dbpwd);
*/
// echo md5($pwd);

/*$str = "qwertyuioplkjhgfdsazxcvbnm78945612301234569870QWZXCVBNMLKJHGFDSARTYUIOP@|][)(*&^$#@!";
$otp = substr(str_shuffle($str),6,20);
//Integrate SMS API
echo $otp;
*/


/*
$name ="           Ram Babburi       ";
echo trim($name);
*/

//$name = "Ram's Profile's";

//$name = "Ram\'s Profile\'s";

//echo stripslashes($name);




//echo strip_tags($name);


//echo str_replace("html","PHP",$str);
//echo str_ireplace("html","PHP",$str);

/*
$str = "10#20#30#40#50";
$arr = explode("#", $str);
print_r($arr);
*/

/*$arr = [10,20,30,40,50];
echo implode(" ",$arr);
*/


//$str = "raM BaBbURi"; // Ram Babburi

/*
$str = "This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version  of the License, or at your option any later version.";
*/
//echo strpos($str,"GNU");
//echo stripos($str,"Gnu");

/*
$i = 0;
while($i < strlen($str))
{
	if($str[$i] == "a")
	{
		echo $str{$i}." ".$i;
		echo "<br>";
	}
	$i++;
}
*/


//echo strpos($str,"a");


/*$str = "This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 3 of the License, or at your option any later version.";
echo substr($str,99,22);
*/
//substr()
//strpos()


//echo ucwords(strtolower($str));

//echo ucwords($str);

//echo ucfirst($str);

//echo strtoupper($str);

//echo strtolower($str);

//echo strlen($str);



//$str = "<h1 style='color:Red;'>Ram Babburi</h1>";
//echo $str;

//$pwd = "ram@1234";








/*$str1 = 'Welcome to Test';

$str2 = <<<XYZ
<html>
	<head>
		<title>Wordpress</title>
	</head>
	<body>
		<h1>Hello WP!</h1>
	</body>
</html>
XYZ;

$str3 = <<<'XYZ'
Welcome to Nowdoc
XYZ;


echo $str2, $str3;
*/
?>
