<?php 

$day = 10;

switch($day)
{
	case 0:
	echo "Sunday";
	break;
	
	case 1:
	echo "Monday";
	break;
	
	case 2:
	echo "Tuesday";
	break;
	
	default:
	echo "Not Macthed";
	
}


//(condition) ? true block : false block;
/*
$x = (10 <= 5) ?  "Yes" : "No";
echo $x;
*/
/*
$m = 85;
if($m >= 90)
{
	echo "GRADE A";
}
else if($m >= 80)
{
	echo "GRADE B";
}
else if($m >= 70)
{
	echo "GRADE C";
}
else if($m >= 60)
{
	echo "GRADE D";
}
else
{
	echo "FAIL";
}
*/

/*
$loginStatus = false;
if($loginStatus)	
{
	echo "<p>Hello Ram</p>";
}
else
{
	echo "<p>Please Login</p>";
}
*/

?>

