<?php 

$x = 100;
$y = 200;

$a = print $x;

echo "<br>";

echo $a;

//echo echo $x;


//echo $x, $y;
//print $x, $y;


//echo $x;
//echo $y;

//print $x;
//print $y;



/*
$status = false;
echo $status; 
*/
// true - 1
// false - no value or empty


/*
$name = "Ram Babburi";
echo '<h1>Welcome to ' .$name.'</h1>';
*/

/*
$x = 100;
$y = 200;
$z = $x + $y;
echo "<p>The sum of $x and $y is: $z</p>";
echo '<p>The sum of ' .$x. ' and ' .$y. ' is: ' .$z. '</p>';
*/

/*$a = 100;
$subject = "PHP&MySQL";
$lastname = "Babburi";
$firstname = "Ram";

$price = 100.258;

$status = true;

$myFav123Subject = "PHP";

$MSG = "Welcome";
*/


?>

