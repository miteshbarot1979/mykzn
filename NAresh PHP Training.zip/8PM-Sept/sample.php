<?php echo "Start"; ?>
<html>
	<head>
		<title><?php echo "Hello Ram";?></title>
	</head>
	<body>
		<h1>Welcome to Php</h1>
		<h3><?php echo "hello";?></h3>
	</body>
</html>
<?php echo "End";?>